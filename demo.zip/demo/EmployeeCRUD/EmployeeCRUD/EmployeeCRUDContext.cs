using Microsoft.EntityFrameworkCore;

public class EmployeeCRUDContext(DbContextOptions<EmployeeCRUDContext> options) : DbContext(options)
{
    public DbSet<EmployeeCRUD.Models.Employee> Employee { get; set; } = default!;
}
