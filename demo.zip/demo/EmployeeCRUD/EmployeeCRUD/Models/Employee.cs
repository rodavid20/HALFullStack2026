﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeCRUD.Models
{
    public class Employee
    {
        [Required]
        public int Id { get; set; }

        [Required, MaxLength(20)]
        public string Name { get; set; } = string.Empty;
        
        public decimal Salary { get; set; }

        public string Email { get; set; } = string.Empty;
    }
}
