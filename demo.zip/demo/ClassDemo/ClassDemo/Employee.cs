﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassDemo
{
    internal class Employee : IPrintable
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal Salary { get; set; }

        public void Print()
        {
            Console.WriteLine($"Employee Id: {Id}");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Salary: {Salary}");
        }
    }

    internal class Student :IPrintable
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Semester { get; set; }

        public void Print()
        {
            Console.WriteLine($"Student Id: {Id}");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Semester: {Semester}");
        }
    }

    internal interface IPrintable
    {
        public int Id { get; set; }
        public string Name { get; set; }

        void Print();
    }

    internal class PrintVistingCard
    {
        public void Print(IPrintable printableObj)
        {
            printableObj.Print();
        }
    }
}
