using Microsoft.EntityFrameworkCore;

public class EmployeesWebAPIContext(DbContextOptions<EmployeesWebAPIContext> options) : DbContext(options)
{
    public DbSet<EmployeesWebAPI.Models.Employee> Employee { get; set; } = default!;
}
