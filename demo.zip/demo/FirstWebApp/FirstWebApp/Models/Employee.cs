﻿namespace FirstWebApp.Models
{
    public class Employee
    {
        public static string CompanyName = string.Empty;
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Salary { get; set; }

        public Employee(int id, string name, int salary)
        {
            Id = id;
            Name = name;
            Salary = salary;
        }
    }
}
