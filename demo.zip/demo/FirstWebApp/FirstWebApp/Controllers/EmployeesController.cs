﻿
using FirstWebApp.Models;
using FirstWebApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace FirstWebApp.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly IEmployeeDataStore _employeeDataStore;

        public EmployeesController(IEmployeeDataStore employeeDataStore)
        {
            _employeeDataStore = employeeDataStore;
        }
        public IActionResult Index()
        {
            //Employee employee = new(1, "abc", 10000);

           /* List<Employee> employees = [
                new(1, "abc", 10000), 
                new(2, "xyz", 20000), 
                new(3, "pqr", 30000)];*/

            
            return View(_employeeDataStore.GetAllEmployees());
        }
    }
}
