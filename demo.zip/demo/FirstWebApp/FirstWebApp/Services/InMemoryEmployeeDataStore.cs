﻿using FirstWebApp.Models;
using System.Collections.Generic;

namespace FirstWebApp.Services
{
    public class InMemoryEmployeeDataStore : IEmployeeDataStore
    {
        private readonly List<Employee> _employees = [
                new(1, "abc", 10000),
                new(2, "xyz", 20000),
                new(3, "pqr", 30000)];

        public List<Employee> GetAllEmployees()
        {
            return _employees;
        }
    }
}
