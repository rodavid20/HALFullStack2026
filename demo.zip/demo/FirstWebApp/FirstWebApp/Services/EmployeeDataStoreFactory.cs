﻿namespace FirstWebApp.Services
{
   public static class EmployeeDataStoreFactory
    {
        public static IEmployeeDataStore Create()
        {
            return new InMemoryEmployeeDataStore();
        }
    }
}
