﻿using FirstWebApp.Models;

namespace FirstWebApp.Services
{
    public interface IEmployeeDataStore
    {
        List<Employee> GetAllEmployees();
    }
}
