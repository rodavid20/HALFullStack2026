﻿using System;
using System.Collections.Generic;

namespace ShapeCalculator
{
    internal class Square: IShape
    {   
        public int Side {  get; set; }

        public Square(int side)
        {
            Side = side;
        }

        public int CalculateArea()
        {
            return Side*Side;
        }

    }
}
