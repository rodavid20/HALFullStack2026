﻿
namespace ShapeCalculator
{
    internal class Rectangle: IShape
    {
        public int Length {  get; set; }
        public int Width { get; set; }

        public Rectangle(int length, int width)
        {
            Length = length;
            Width = width;
        }

        public int CalculateArea()
        {
            return Length*Width;
        }

    }
}
