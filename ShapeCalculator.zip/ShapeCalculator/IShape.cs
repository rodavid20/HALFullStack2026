﻿namespace ShapeCalculator
{
    internal interface IShape
    {
        int CalculateArea();
    }
}
