﻿namespace ShapeCalculator
{
    internal class AreaCalculator
    {
        public int Calculate(IShape shape) 
        {
            return shape.CalculateArea();
        }
    }
}
