﻿// See https://aka.ms/new-console-template for more information
using ShapeCalculator;
using System.Drawing;

Console.WriteLine("Hello, World!");
/*
ShapeCalculator.Rectangle rect = new(10, 5);
Console.WriteLine("Area: " + rect.CalculateArea());

rect = new(7, 10);
Console.WriteLine("Area: " + rect.CalculateArea());
*/

AreaCalculator areaCalculator = new AreaCalculator();
ShapeCalculator.Rectangle rect = new(10, 5);
Console.WriteLine(areaCalculator.Calculate(rect));

Square square = new(10);
Console.WriteLine(areaCalculator.Calculate(square));


